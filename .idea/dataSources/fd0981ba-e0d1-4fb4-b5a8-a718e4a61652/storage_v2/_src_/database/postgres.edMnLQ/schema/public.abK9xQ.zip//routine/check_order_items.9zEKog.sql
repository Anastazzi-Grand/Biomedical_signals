create function check_order_items() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Проверяем, что заказ обновляется, а не создается
    IF TG_OP = 'UPDATE' THEN
        -- Проверяем, что в заказе есть хотя бы один продукт
        IF NOT EXISTS (
            SELECT 1
            FROM OrderItems
            WHERE OrderId = NEW.Id
        ) THEN
            RAISE EXCEPTION 'Заказ должен содержать хотя бы один продукт';
        END IF;
    END IF;
    RETURN NEW;
END;
$$;

alter function check_order_items() owner to postgres;

