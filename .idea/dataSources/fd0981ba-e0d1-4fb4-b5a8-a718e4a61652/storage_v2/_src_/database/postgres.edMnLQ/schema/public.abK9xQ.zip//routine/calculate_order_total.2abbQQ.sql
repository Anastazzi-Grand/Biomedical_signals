create function calculate_order_total() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE Orders
    SET TotalPrice = (
        SELECT SUM(p.Price * oi.Quantity)
        FROM OrderItems oi
        JOIN Product p ON oi.ProductId = p.Id
        WHERE oi.OrderId = COALESCE(NEW.OrderId, OLD.OrderId)
    )
    WHERE Id = COALESCE(NEW.OrderId, OLD.OrderId)
    AND EXISTS (SELECT 1 FROM Orders WHERE Id = COALESCE(NEW.OrderId, OLD.OrderId));
    RAISE NOTICE 'ЋЎй п бв®Ё¬®бвм § Є §  гбЇҐи­® а ббзЁв ­ .';
    RETURN NEW;
END;
$$;

alter function calculate_order_total() owner to postgres;

