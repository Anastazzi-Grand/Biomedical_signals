create procedure update_pizza_price(IN pizza_id integer, IN new_price numeric)
    language plpgsql
as
$$
BEGIN
    UPDATE pizzas
    SET price = new_price
    WHERE pizzas.pizza_id = update_pizza_price.pizza_id;

    RAISE NOTICE 'Цена пиццы с ID % успешно обновлена на %', pizza_id, new_price;
END;
$$;

alter procedure update_pizza_price(integer, numeric) owner to postgres;

