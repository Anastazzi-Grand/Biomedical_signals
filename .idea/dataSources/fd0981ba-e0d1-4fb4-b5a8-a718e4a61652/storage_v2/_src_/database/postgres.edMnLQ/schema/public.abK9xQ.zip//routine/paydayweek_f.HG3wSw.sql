create function paydayweek_f(i_date date) returns text
    immutable
    language sql
as
$$ 
select (case when i_date is null then 'nodate' 
else 
CASE EXTRACT(dow FROM i_date)
WHEN 0 THEN '‚®бЄаҐбҐ­мҐ'
WHEN 1 THEN 'Џ®­Ґ¤Ґ«м­ЁЄ'
WHEN 2 THEN '‚в®а­ЁЄ'
WHEN 3 THEN '‘аҐ¤ '
WHEN 4 THEN '—ҐвўҐаЈ'
WHEN 5 THEN 'Џпв­Ёж '
WHEN 6 THEN '‘гЎЎ®в '
end
end); 
$$;

alter function paydayweek_f(date) owner to postgres;

