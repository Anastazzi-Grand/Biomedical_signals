create procedure get_order_info(IN order_id integer)
    language plpgsql
as
$$
DECLARE
    order_row orders%ROWTYPE;
BEGIN
    SELECT * INTO order_row
    FROM orders
    WHERE orders.order_id = get_order_info.order_id;

    RAISE NOTICE 'Информация о заказе %:', order_id;
    RAISE NOTICE 'Идентификатор заказа: %', order_row.order_id;
    RAISE NOTICE 'Идентификатор клиента: %', order_row.customer_id;
    RAISE NOTICE 'Дата заказа: %', order_row.order_date;
    RAISE NOTICE 'Общая стоимость: %', order_row.total_price;
    RAISE NOTICE 'Статус: %', order_row.status;
END;
$$;

alter procedure get_order_info(integer) owner to postgres;

