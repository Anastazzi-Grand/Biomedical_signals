create function limit_ingredients() returns trigger
    language plpgsql
as
$$
DECLARE
    ingredient_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO ingredient_count
    FROM pizza_ingredients
    WHERE pizza_id = NEW.pizza_id;

    IF ingredient_count >= 10 THEN
        RAISE EXCEPTION 'Максимальное количество ингредиентов в пицце (10) достигнуто';
    END IF;

    RETURN NEW;
END;
$$;

alter function limit_ingredients() owner to postgres;

