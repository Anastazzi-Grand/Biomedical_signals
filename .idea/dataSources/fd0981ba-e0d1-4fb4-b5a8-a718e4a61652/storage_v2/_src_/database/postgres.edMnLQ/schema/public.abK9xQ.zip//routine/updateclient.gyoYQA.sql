create procedure updateclient(IN p_id integer, IN p_fullname character varying, IN p_phonenumber character varying)
    language plpgsql
as
$$
BEGIN
    UPDATE Client
    SET FullName = p_FullName,
        PhoneNumber = p_PhoneNumber
    WHERE Id = p_Id;
    COMMIT;
END;
$$;

alter procedure updateclient(integer, varchar, varchar) owner to postgres;

