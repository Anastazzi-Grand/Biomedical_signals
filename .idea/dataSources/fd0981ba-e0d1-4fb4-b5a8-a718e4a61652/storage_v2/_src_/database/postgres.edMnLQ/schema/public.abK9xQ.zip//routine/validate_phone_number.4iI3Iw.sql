create function validate_phone_number() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Проверяем, что номер телефона начинается с +7 или 8 и состоит из 11 цифр
    IF NEW.PhoneNumber !~ '^(\+7|8)\d{10}$' THEN
        RAISE EXCEPTION 'Неверный формат номера телефона: %', NEW.PhoneNumber;
    END IF;
    RETURN NEW;
END;
$$;

alter function validate_phone_number() owner to postgres;

