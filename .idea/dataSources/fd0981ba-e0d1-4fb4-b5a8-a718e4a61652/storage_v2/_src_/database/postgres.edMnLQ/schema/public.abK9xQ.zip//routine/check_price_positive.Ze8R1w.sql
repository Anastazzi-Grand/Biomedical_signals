create function check_price_positive() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.price < 0 THEN
        RAISE EXCEPTION 'Цена не может быть отрицательной!';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_price_positive() owner to postgres;

