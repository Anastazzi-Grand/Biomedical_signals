create procedure deleteclient(IN p_id integer)
    language plpgsql
as
$$
BEGIN
    DELETE FROM Client
    WHERE Id = p_Id;
    COMMIT;
END;
$$;

alter procedure deleteclient(integer) owner to postgres;

