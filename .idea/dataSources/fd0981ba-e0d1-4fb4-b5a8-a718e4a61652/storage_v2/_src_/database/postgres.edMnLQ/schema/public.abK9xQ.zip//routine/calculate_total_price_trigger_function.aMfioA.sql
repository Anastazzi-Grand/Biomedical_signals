create function calculate_total_price_trigger_function() returns trigger
    language plpgsql
as
$$
DECLARE
    product_price DECIMAL(10,2);
BEGIN
    -- Получаем цену продукта из таблицы product
    SELECT p.price INTO product_price
    FROM product p
    WHERE p.id = NEW.productid;

    -- Рассчитываем totalprice, добавляя 30 рублей к цене продукта
    NEW.totalprice := product_price + 30.00;

    RETURN NEW;
END;
$$;

alter function calculate_total_price_trigger_function() owner to postgres;

