create procedure addclient(IN p_fullname character varying, IN p_phonenumber character varying)
    language plpgsql
as
$$
BEGIN
    INSERT INTO Client (FullName, PhoneNumber)
    VALUES (p_FullName, p_PhoneNumber);
    COMMIT;
END;
$$;

alter procedure addclient(varchar, varchar) owner to postgres;

