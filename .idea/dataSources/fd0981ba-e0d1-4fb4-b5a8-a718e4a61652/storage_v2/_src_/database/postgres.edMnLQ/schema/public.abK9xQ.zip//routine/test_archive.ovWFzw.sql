create function test_archive(order_id_param integer) returns void
    language plpgsql
as
$$
DECLARE
    old_order orders%ROWTYPE;
BEGIN
    SELECT * INTO old_order FROM orders WHERE order_id = order_id_param;

    -- Удаляем связанные записи из order_pizzas
    DELETE FROM order_pizzas 
    WHERE order_id = old_order.order_id;

    -- Вставляем старый заказ в archived_orders
    INSERT INTO archived_orders (order_id, customer_id, total_price, status, order_date)
    VALUES (old_order.order_id, old_order.customer_id, old_order.total_price, old_order.status, old_order.order_date);

    -- Удаляем старый заказ из orders
    DELETE FROM orders 
    WHERE order_id = old_order.order_id;
END;
$$;

alter function test_archive(integer) owner to postgres;

