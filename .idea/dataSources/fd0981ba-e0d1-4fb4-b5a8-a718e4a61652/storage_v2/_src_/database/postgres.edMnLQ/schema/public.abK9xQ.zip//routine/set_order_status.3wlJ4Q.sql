create function set_order_status() returns trigger
    language plpgsql
as
$$
BEGIN
    IF TG_OP = 'INSERT' THEN
        NEW.status := CONVERT_TO('‘®§¤ ­', 'UTF8');
    ELSIF TG_OP = 'UPDATE' THEN
        NEW.status := CONVERT_TO('ѓ®в®ўЁвбп', 'UTF8');
    END IF;
    RETURN NEW;
END;
$$;

alter function set_order_status() owner to postgres;

