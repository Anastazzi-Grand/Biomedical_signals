create procedure add_new_pizza(IN pizza_name text, IN pizza_price numeric)
    language plpgsql
as
$$
DECLARE
    new_pizza_id INTEGER;
BEGIN
    INSERT INTO pizzas (name, price)
    VALUES (pizza_name, pizza_price)
    RETURNING pizza_id INTO new_pizza_id;

    RAISE NOTICE 'Новая пицца % успешно добавлена с ID %', pizza_name, new_pizza_id;
END;
$$;

alter procedure add_new_pizza(text, numeric) owner to postgres;

