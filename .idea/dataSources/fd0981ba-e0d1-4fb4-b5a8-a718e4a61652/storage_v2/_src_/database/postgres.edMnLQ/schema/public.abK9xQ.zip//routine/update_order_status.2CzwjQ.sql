create function update_order_status() returns trigger
    language plpgsql
as
$$
BEGIN
    UPDATE orders
    SET status = 'В процессе'
    WHERE order_id = NEW.order_id;
    RETURN NEW;
END;
$$;

alter function update_order_status() owner to postgres;

