create function archive_old_orders() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Удаляем связанные записи из order_pizzas
    DELETE FROM order_pizzas 
    WHERE order_id = OLD.order_id;

    -- Вставляем старый заказ в archived_orders
    INSERT INTO archived_orders (order_id, customer_id, total_price, status, order_date)
    VALUES (OLD.order_id, OLD.customer_id, OLD.total_price, OLD.status, OLD.order_date);

    -- Удаляем старый заказ из orders
    DELETE FROM orders 
    WHERE order_id = OLD.order_id;

    RETURN NULL;
END;
$$;

alter function archive_old_orders() owner to postgres;

