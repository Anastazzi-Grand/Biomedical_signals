create function check_order_date_trigger_function_for_orders() returns trigger
    language plpgsql
as
$$
BEGIN
    IF NEW.orderdate > CURRENT_DATE THEN
        RAISE EXCEPTION 'Вы не можете выбрать дату, которая еще не наступила!';
    END IF;
    RETURN NEW;
END;
$$;

alter function check_order_date_trigger_function_for_orders() owner to postgres;

