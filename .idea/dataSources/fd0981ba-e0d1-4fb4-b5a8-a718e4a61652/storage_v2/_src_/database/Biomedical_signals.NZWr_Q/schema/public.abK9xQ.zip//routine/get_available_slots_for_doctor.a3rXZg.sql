create function get_available_slots_for_doctor(doctor_id_input integer)
    returns TABLE(doctor_fio character varying, work_date date, start_time time without time zone, end_time time without time zone, free_slot time without time zone)
    language plpgsql
as
$$
DECLARE
    slot_interval INTERVAL := '30 minutes'; -- Шаг временного слота (30 минут)
BEGIN
    -- Проверка, что входной параметр не NULL
    IF doctor_id_input IS NULL THEN
        RAISE EXCEPTION 'Входной параметр DoctorID не может быть NULL.';
    END IF;

    -- Проверка существования врача
    IF NOT EXISTS (SELECT 1 FROM Doctor WHERE DoctorID = doctor_id_input) THEN
        RAISE EXCEPTION 'Врач с ID % не существует.', doctor_id_input;
    END IF;

    -- Генерация всех возможных временных слотов и проверка их доступности
    RETURN QUERY
    WITH all_slots AS (
        SELECT 
            d.Doctor_FIO,
            ds.WorkDate,
            ds.StartTime,
            ds.EndTime,
            generate_series(
                ds.WorkDate + ds.StartTime, -- Преобразование в TIMESTAMP
                ds.WorkDate + ds.EndTime - INTERVAL '30 minutes', -- Преобразование в TIMESTAMP
                slot_interval
            )::TIME AS slot_time -- Преобразование обратно в TIME
        FROM 
            Doctor_Schedule ds
        JOIN 
            Doctor d ON ds.DoctorID = d.DoctorID
        WHERE 
            ds.DoctorID = doctor_id_input
            AND ds.WorkDate BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '21 days')
    ),
    busy_slots AS (
        SELECT 
            s.Session_Date,
            s.Session_StartTime
        FROM 
            Session s
        WHERE 
            s.DoctorID = doctor_id_input
    )
    SELECT 
        a.Doctor_FIO,
        a.WorkDate,
        a.StartTime,
        a.EndTime,
        a.slot_time AS free_slot
    FROM 
        all_slots a
    LEFT JOIN 
        busy_slots b 
        ON a.WorkDate = b.Session_Date 
        AND a.slot_time = b.Session_StartTime
    WHERE 
        b.Session_StartTime IS NULL -- Слоты, которые не заняты
    ORDER BY 
        a.WorkDate, a.slot_time;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Произошла ошибка: %', SQLERRM;
END;
$$;

alter function get_available_slots_for_doctor(integer) owner to postgres;

