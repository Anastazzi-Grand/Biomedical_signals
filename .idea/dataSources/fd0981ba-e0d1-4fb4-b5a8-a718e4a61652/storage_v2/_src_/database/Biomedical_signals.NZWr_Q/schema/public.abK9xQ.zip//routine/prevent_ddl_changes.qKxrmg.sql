create function prevent_ddl_changes() returns event_trigger
    language plpgsql
as
$$
BEGIN
    -- Разрешаем изменения для пользователя postgres и роли admin
    IF SESSION_USER NOT IN ('postgres') THEN
        RAISE EXCEPTION 'Запрещено изменять структуру базы данных без разрешения администратора.';
    END IF;
END;
$$;

alter function prevent_ddl_changes() owner to postgres;

