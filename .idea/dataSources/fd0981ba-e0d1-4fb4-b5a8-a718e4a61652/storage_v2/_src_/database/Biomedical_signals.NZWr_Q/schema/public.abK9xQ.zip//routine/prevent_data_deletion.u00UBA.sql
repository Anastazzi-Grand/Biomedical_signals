create function prevent_data_deletion() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Проверяем тип таблицы
    IF TG_TABLE_NAME = 'pg_data' THEN
        -- Для таблицы PG_Data проверяем Amplitude
        IF OLD.Amplitude IS NOT NULL THEN
            RAISE EXCEPTION 'Запись содержит обработанные данные амплитуды сигнала дыхания и не может быть удалена.';
        END IF;
    ELSIF TG_TABLE_NAME = 'ecs_data' THEN
        -- Для таблицы ECS_Data проверяем RR_Time
        IF OLD.RR_Time IS NOT NULL THEN
            RAISE EXCEPTION 'Запись содержит обработанные данные длительности RR-интервала и не может быть удалена.';
        END IF;
    ELSE
        -- Для других таблиц можно добавить дополнительные условия
        RAISE EXCEPTION 'Неизвестная таблица %', TG_TABLE_NAME;
    END IF;

    RETURN OLD;
END;
$$;

alter function prevent_data_deletion() owner to postgres;

