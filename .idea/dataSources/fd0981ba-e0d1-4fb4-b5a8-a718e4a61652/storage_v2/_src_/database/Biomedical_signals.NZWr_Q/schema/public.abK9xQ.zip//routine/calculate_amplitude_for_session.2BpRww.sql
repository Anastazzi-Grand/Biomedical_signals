create function calculate_amplitude_for_session(session_id_input integer) returns void
    language plpgsql
as
$$
BEGIN
    -- Проверка существования сеанса
    IF NOT EXISTS (SELECT 1 FROM Session WHERE SessionID = session_id_input) THEN
        RAISE EXCEPTION 'Сеанс с ID % не существует.', session_id_input;
    END IF;

    -- Обновление амплитуды на основе новой формулы
    UPDATE PG_Data
    SET Amplitude = ROUND(
        ((D1 * 256 + D2) * 2.45 / POWER(2, 10))::NUMERIC,
        3  -- Округление до 3 знаков после запятой
    )
    WHERE SessionID = session_id_input;

    -- Проверка, были ли обновлены записи
    IF NOT FOUND THEN
        RAISE NOTICE 'Для сеанса с ID % нет данных ПГ для обновления.', session_id_input;
    ELSE
        RAISE NOTICE 'Амплитуда сигнала дыхания успешно обновлена для сеанса с ID %.', session_id_input;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Произошла ошибка при расчете амплитуды: %', SQLERRM;
END;
$$;

alter function calculate_amplitude_for_session(integer) owner to postgres;

grant execute on function calculate_amplitude_for_session(integer) to engineer_researcher;

