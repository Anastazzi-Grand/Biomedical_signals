create function calculate_rr_duration_for_session(session_id_input integer) returns void
    language plpgsql
as
$$
DECLARE
    dt CONSTANT FLOAT := 5.0 / 1000; -- Константа времени (5 мс в секундах)
BEGIN
    -- Проверка существования сеанса
    IF NOT EXISTS (SELECT 1 FROM Session WHERE SessionID = session_id_input) THEN
        RAISE EXCEPTION 'Сеанс с ID % не существует.', session_id_input;
    END IF;

    -- Обновление длительности RR-интервала для всех записей ЭКС, связанных с указанным сеансом
    UPDATE ECS_Data
    SET RR_Time = RR_Length * dt
    WHERE SessionID = session_id_input;

    -- Проверка, были ли обновлены записи
    IF NOT FOUND THEN
        RAISE NOTICE 'Для сеанса с ID % нет данных ЭКС для обновления.', session_id_input;
    ELSE
        RAISE NOTICE 'Длительность RR-интервала успешно обновлена для сеанса с ID %.', session_id_input;
    END IF;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Произошла ошибка при расчете длительности RR-интервала: %', SQLERRM;
END;
$$;

alter function calculate_rr_duration_for_session(integer) owner to postgres;

grant execute on function calculate_rr_duration_for_session(integer) to engineer_researcher;

