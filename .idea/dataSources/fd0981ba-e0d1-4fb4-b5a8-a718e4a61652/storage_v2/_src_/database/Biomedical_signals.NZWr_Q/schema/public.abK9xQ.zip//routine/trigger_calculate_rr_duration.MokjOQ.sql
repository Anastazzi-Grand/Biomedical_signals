create function trigger_calculate_rr_duration() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Проверяем глубину рекурсии
    IF pg_trigger_depth() > 1 THEN
        RETURN NEW; -- Если триггер уже вызван рекурсивно, завершаем выполнение
    END IF;

    -- Вызываем функцию расчета длительности RR-интервала
    PERFORM calculate_rr_duration_for_session(NEW.SessionID);
    RETURN NEW;
END;
$$;

alter function trigger_calculate_rr_duration() owner to postgres;

