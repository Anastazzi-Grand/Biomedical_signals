create function trigger_calculate_amplitude() returns trigger
    language plpgsql
as
$$
BEGIN
    -- Проверяем глубину рекурсии
    IF pg_trigger_depth() > 1 THEN
        RETURN NEW; -- Если триггер уже вызван рекурсивно, завершаем выполнение
    END IF;

    -- Вызываем функцию расчета амплитуды
    PERFORM calculate_amplitude_for_session(NEW.SessionID);
    RETURN NEW;
END;
$$;

alter function trigger_calculate_amplitude() owner to postgres;

