create function check_session_time() returns trigger
    language plpgsql
as
$$
DECLARE
    is_doctor_available BOOLEAN;
    is_time_slot_free BOOLEAN;
BEGIN
    -- Проверяем, свободен ли врач в выбранное время
    SELECT EXISTS (
        SELECT 1
        FROM Doctor_Schedule ds
        WHERE ds.DoctorID = NEW.DoctorID
          AND NEW.Session_Date = ds.WorkDate
          AND NEW.Session_StartTime >= ds.StartTime
          AND NEW.Session_StartTime < ds.EndTime
    ) INTO is_doctor_available;

    IF NOT is_doctor_available THEN
        RAISE EXCEPTION 'Выбранное время выходит за пределы рабочего графика врача.';
    END IF;

    -- Проверяем, что указанные дата, время и врач не заняты
    SELECT NOT EXISTS (
        SELECT 1
        FROM Session s
        WHERE s.DoctorID = NEW.DoctorID
          AND s.Session_Date = NEW.Session_Date
          AND (
              (NEW.Session_StartTime >= s.Session_StartTime AND NEW.Session_StartTime < s.Session_EndTime) OR
              (NEW.Session_EndTime > s.Session_StartTime AND NEW.Session_EndTime <= s.Session_EndTime) OR
              (NEW.Session_StartTime <= s.Session_StartTime AND NEW.Session_EndTime >= s.Session_EndTime)
          )
    ) INTO is_time_slot_free;

    IF NOT is_time_slot_free THEN
        RAISE EXCEPTION 'Указанный временной слот уже занят другим пациентом.';
    END IF;

    RETURN NEW;
END;
$$;

alter function check_session_time() owner to postgres;

