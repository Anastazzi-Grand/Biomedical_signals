create function log_user_login() returns event_trigger
    language plpgsql
as
$$
BEGIN
    INSERT INTO login_audit (username) VALUES (current_user);
END;
$$;

alter function log_user_login() owner to postgres;

