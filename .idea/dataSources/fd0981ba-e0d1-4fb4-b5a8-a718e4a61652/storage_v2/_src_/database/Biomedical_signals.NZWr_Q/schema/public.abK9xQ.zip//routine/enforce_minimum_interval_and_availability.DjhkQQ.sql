create function enforce_minimum_interval_and_availability() returns trigger
    language plpgsql
as
$$
DECLARE
    last_session_time TIMESTAMP;
    next_available_time TIMESTAMP;
BEGIN
    -- Находим время последней записи в той же лаборатории
    SELECT MAX(make_timestamp(
                   EXTRACT(YEAR FROM Session_Date)::INT,
                   EXTRACT(MONTH FROM Session_Date)::INT,
                   EXTRACT(DAY FROM Session_Date)::INT,
                   EXTRACT(HOUR FROM Session_StartTime)::INT,
                   EXTRACT(MINUTE FROM Session_StartTime)::INT,
                   0
               ))
    INTO last_session_time
    FROM Session
    WHERE LabID = NEW.LabID;

    -- Если есть предыдущая запись, проверяем интервал
    IF last_session_time IS NOT NULL THEN
        next_available_time := last_session_time + INTERVAL '30 minutes';

        -- Если новое время меньше минимального интервала, корректируем его
        IF make_timestamp(
               EXTRACT(YEAR FROM NEW.Session_Date)::INT,
               EXTRACT(MONTH FROM NEW.Session_Date)::INT,
               EXTRACT(DAY FROM NEW.Session_Date)::INT,
               EXTRACT(HOUR FROM NEW.Session_StartTime)::INT,
               EXTRACT(MINUTE FROM NEW.Session_StartTime)::INT,
               0
           ) < next_available_time THEN
            NEW.Session_StartTime := next_available_time::TIME;
            NEW.Session_EndTime := (next_available_time + (NEW.Session_EndTime - NEW.Session_StartTime))::TIME;
            RAISE NOTICE 'Время начала сеанса скорректировано на %.', NEW.Session_StartTime;
        END IF;
    END IF;

    -- Проверяем, что выбранное время не занято указанными датой, врачом и лабораторией
    IF EXISTS (
        SELECT 1
        FROM Session s
        WHERE s.DoctorID = NEW.DoctorID
          AND s.LabID = NEW.LabID
          AND s.Session_Date = NEW.Session_Date
          AND (
              (NEW.Session_StartTime >= s.Session_StartTime AND NEW.Session_StartTime < s.Session_EndTime) OR
              (NEW.Session_EndTime > s.Session_StartTime AND NEW.Session_EndTime <= s.Session_EndTime) OR
              (NEW.Session_StartTime <= s.Session_StartTime AND NEW.Session_EndTime >= s.Session_EndTime)
          )
    ) THEN
        RAISE EXCEPTION 'Выбранное время уже занято другим пациентом в указанной лаборатории.';
    END IF;

    RETURN NEW;
END;
$$;

alter function enforce_minimum_interval_and_availability() owner to postgres;

