create function count_sessions_for_patient(patient_id_input integer, start_date date DEFAULT NULL::date, end_date date DEFAULT NULL::date) returns integer
    language plpgsql
as
$$
DECLARE
    session_count INT;
BEGIN
    -- Проверка существования пациента
    IF NOT EXISTS (SELECT 1 FROM Patient WHERE PatientID = patient_id_input) THEN
        RAISE EXCEPTION 'Пациент с ID % не существует.', patient_id_input;
    END IF;

    -- Проверка, что дата начала не больше даты конца
    IF start_date IS NOT NULL AND end_date IS NOT NULL AND start_date > end_date THEN
        RAISE EXCEPTION 'Дата начала (%) не может быть больше даты конца (%).', start_date, end_date;
    END IF;

    -- Подсчет количества сеансов с учетом условий для дат
    SELECT COUNT(*) INTO session_count
    FROM Session
    WHERE PatientID = patient_id_input
      AND (start_date IS NULL OR Session_Date >= start_date)
      AND (end_date IS NULL OR Session_Date <= end_date);

    -- Возврат результата
    RETURN session_count;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Произошла ошибка при подсчете сеансов: %', SQLERRM;
END;
$$;

alter function count_sessions_for_patient(integer, date, date) owner to postgres;

grant execute on function count_sessions_for_patient(integer, date, date) to doctor;

grant execute on function count_sessions_for_patient(integer, date, date) to administrator;

