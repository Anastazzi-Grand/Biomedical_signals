create function get_doctor_schedule_in_clinic(clinic_id_input integer)
    returns TABLE(doctor_fio character varying, work_date date, start_time time without time zone, end_time time without time zone)
    language plpgsql
as
$$
BEGIN
    -- Проверка, что входной параметр не NULL
    IF clinic_id_input IS NULL THEN
        RAISE EXCEPTION 'Входной параметр не может быть NULL.';
    END IF;

    -- Проверка существования поликлиники
    IF NOT EXISTS (SELECT 1 FROM Polyclinic WHERE PolyclinicID = clinic_id_input) THEN
        RAISE EXCEPTION 'Поликлиника с ID % не существует.', clinic_id_input;
    END IF;

    RETURN QUERY
    SELECT 
        d.Doctor_FIO,
        ds.WorkDate,
        ds.StartTime,
        ds.EndTime
    FROM 
        Doctor_Schedule ds
    JOIN 
        Doctor d ON ds.DoctorID = d.DoctorID
    WHERE 
        d.PolyclinicID = clinic_id_input
        AND ds.WorkDate BETWEEN CURRENT_DATE AND (CURRENT_DATE + INTERVAL '21 days')
    ORDER BY 
        ds.WorkDate, ds.StartTime;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Произошла ошибка: %', SQLERRM;
END;
$$;

alter function get_doctor_schedule_in_clinic(integer) owner to postgres;

