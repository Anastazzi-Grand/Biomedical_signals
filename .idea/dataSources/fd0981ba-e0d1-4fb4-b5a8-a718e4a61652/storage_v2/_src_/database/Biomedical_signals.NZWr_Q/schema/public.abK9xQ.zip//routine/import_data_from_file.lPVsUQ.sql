create function import_data_from_file(file_path text, session_id integer) returns void
    language plpgsql
as
$$
DECLARE
    file_content TEXT;
    lines TEXT[];
    i INT;
    d1_val INT;
    d2_val INT;
    rr_val INT;
BEGIN
    -- Читаем весь файл
    file_content := pg_read_file(file_path);
    lines := string_to_array(file_content, E'\n');
    
    -- Обрабатываем каждую тройку строк
    FOR i IN 1..array_length(lines, 1) BY 3 LOOP
        IF i + 2 > array_length(lines, 1) THEN
            EXIT; -- Если строк меньше трёх, выходим
        END IF;
        
        d1_val := lines[i]::INT;
        d2_val := lines[i+1]::INT;
        rr_val := lines[i+2]::INT;
        
        -- Вставляем данные
        INSERT INTO PG_Data (SessionID, D1, D2, Amplitude)
        VALUES (session_id, d1_val, d2_val, NULL);
        
        INSERT INTO ECS_Data (SessionID, RR_Length, RR_Time)
        VALUES (session_id, rr_val, NULL);
    END LOOP;
END;
$$;

alter function import_data_from_file(text, integer) owner to postgres;

grant execute on function import_data_from_file(text, integer) to engineer_researcher;

