create function get_last_results_for_patient(patient_id_input integer)
    returns TABLE(diagnosis_name character varying, description text, date_of_diagnosis date, treatment_plan text, additional_remarks text)
    language plpgsql
as
$$
BEGIN
    -- Проверка, что входной параметр не NULL
    IF patient_id_input IS NULL THEN
        RAISE EXCEPTION 'Входной параметр не может быть NULL.';
    END IF;

    -- Проверка существования пациента
    IF NOT EXISTS (SELECT 1 FROM Patient WHERE PatientID = patient_id_input) THEN
        RAISE EXCEPTION 'Пациент с ID % не существует.', patient_id_input;
    END IF;

    RETURN QUERY
    SELECT 
        d.DiagnosisName,
        d.Description,
        d.DateOfDiagnosis,
        tr.TreatmentPlan,
        tr.AdditionalRemarks
    FROM 
        Diagnosis d
    LEFT JOIN 
        Treatment_Recommendation tr ON d.DiagnosisID = tr.DiagnosisID
    WHERE 
        d.PatientID = patient_id_input
    ORDER BY 
        d.DateOfDiagnosis DESC
    LIMIT 1;

EXCEPTION
    WHEN OTHERS THEN
        RAISE EXCEPTION 'Произошла ошибка: %', SQLERRM;
END;
$$;

alter function get_last_results_for_patient(integer) owner to postgres;

grant execute on function get_last_results_for_patient(integer) to doctor;

grant execute on function get_last_results_for_patient(integer) to administrator;

